// Flow 백업 - Content Script (채팅 + 프로젝트, URL 기반 모드 분기)
(function () {
  if (document.getElementById('flow-backup-root')) return;

  let stopFlag = false;
  let currentMode = null; // 'chat' | 'project' | null
  let timerInterval = null;

  // ── URL로 모드 감지 ──
  function detectMode() {
    const url = location.href;
    if (url.includes('messenger.act')) return 'chat';
    if (url.includes('main.act') && (url.includes('detail') || url.includes('srno'))) return 'project';
    return null;
  }

  // ── 플로팅 패널 생성 ──
  const root = document.createElement('div');
  root.id = 'flow-backup-root';
  root.innerHTML = `
    <div id="fb-panel" style="
      position: fixed; bottom: 24px; right: 24px; z-index: 2147483647;
      background: #1a1a2e; border: 1px solid #2a4a7f; border-radius: 12px;
      padding: 14px 16px; width: 230px;
      font-family: 'Malgun Gothic', sans-serif; font-size: 12px; color: #eee;
      box-shadow: 0 4px 24px rgba(0,0,0,0.5); user-select: none; display:none;
    ">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span id="fb-title" style="color:#7eb8f7; font-weight:bold; font-size:13px;">💬 Flow 백업</span>
        <span id="fb-toggle" style="cursor:pointer; color:#aaa; font-size:16px; line-height:1;">−</span>
      </div>
      <div id="fb-body">
        <div id="fb-mode-badge" style="margin-bottom:10px; font-size:11px; color:#aaa; text-align:center;"></div>
        <div style="margin-bottom:12px;">
          <label style="color:#aaa; font-size:11px;">스크롤 속도</label>
          <select id="fb-speed" style="width:100%; margin-top:3px; padding:4px 6px; background:#0f3460; border:1px solid #264d80; border-radius:6px; color:#eee; font-size:12px;">
            <option value="1500">느림 (안정적)</option>
            <option value="1000" selected>보통</option>
            <option value="600">빠름</option>
          </select>
        </div>
        <button id="fb-start" style="width:100%; padding:8px; background:#0e4fa8; color:#fff; border:none; border-radius:8px; font-size:12px; cursor:pointer; font-family:inherit; margin-bottom:5px;">▶ 전체 백업 시작</button>
        <button id="fb-stop" style="width:100%; padding:8px; background:#7b1f1f; color:#fff; border:none; border-radius:8px; font-size:12px; cursor:pointer; font-family:inherit; display:none;">■ 중지 후 저장</button>
        <div id="fb-warning" style="display:none; margin-top:8px; padding:6px 8px; background:#3a1a00; border:1px solid #a05000; border-radius:6px; font-size:11px; color:#ffb347; line-height:1.5; text-align:center;">
          ⚠️ 백업 중 창을 이동하거나<br>다른 탭으로 전환하지 마세요
        </div>
        <div id="fb-timer" style="display:none; margin-top:6px; font-size:11px; color:#aaa; text-align:center;">⏱ 경과 시간: <span id="fb-timer-val">0</span>초</div>
        <div style="margin-top:8px; background:#0a1628; border-radius:4px; height:5px; display:none;" id="fb-prog-wrap">
          <div id="fb-prog-bar" style="height:5px; background:#7eb8f7; border-radius:4px; width:0%; transition:width 0.3s;"></div>
        </div>
        <div id="fb-status" style="margin-top:8px; font-size:11px; color:#7eb8f7; text-align:center; min-height:32px; line-height:1.6;"></div>
      </div>
    </div>
  `;
  document.body.appendChild(root);

  const panel = document.getElementById('fb-panel');

  document.getElementById('fb-toggle').addEventListener('click', () => {
    const body = document.getElementById('fb-body');
    const toggle = document.getElementById('fb-toggle');
    const collapsed = body.style.display === 'none';
    body.style.display = collapsed ? 'block' : 'none';
    toggle.textContent = collapsed ? '−' : '+';
  });

  let dragging = false, ox = 0, oy = 0;
  panel.addEventListener('mousedown', e => {
    if (['SELECT','INPUT','BUTTON'].includes(e.target.tagName)) return;
    dragging = true;
    ox = e.clientX - panel.getBoundingClientRect().left;
    oy = e.clientY - panel.getBoundingClientRect().top;
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    panel.style.left = (e.clientX - ox) + 'px';
    panel.style.top  = (e.clientY - oy) + 'px';
    panel.style.right = 'auto'; panel.style.bottom = 'auto';
  });
  document.addEventListener('mouseup', () => dragging = false);

  // ── 공통 유틸 ──
  function setStatus(msg, progress = null) {
    document.getElementById('fb-status').textContent = msg;
    if (progress !== null) {
      document.getElementById('fb-prog-wrap').style.display = 'block';
      document.getElementById('fb-prog-bar').style.width = Math.min(100, progress) + '%';
    }
  }

  function resetUI() {
    document.getElementById('fb-start').style.display = 'block';
    document.getElementById('fb-stop').style.display = 'none';
    document.getElementById('fb-warning').style.display = 'none';
    document.getElementById('fb-timer').style.display = 'none';
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
  }

  function startTimer() {
    const start = Date.now();
    document.getElementById('fb-warning').style.display = 'block';
    document.getElementById('fb-timer').style.display = 'block';
    timerInterval = setInterval(() => {
      document.getElementById('fb-timer-val').textContent = Math.floor((Date.now() - start) / 1000);
    }, 1000);
  }

  async function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function nowStr() {
    const now = new Date();
    return `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}_${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;
  }

  function exportToCSV(rows, headers, filename) {
    const BOM = '\uFEFF';
    const csv = BOM + [headers.join(','), ...rows.map(r =>
      r.map(v => `"${(v||'').replace(/\r?\n/g,'↵').replace(/"/g,'""')}"`).join(',')
    )].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }

  function htmlToText(html) {
    if (!html) return '';
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    tmp.querySelectorAll('br').forEach(el => el.replaceWith('\n'));
    tmp.querySelectorAll('p,div,li,tr').forEach(el => el.appendChild(document.createTextNode('\n')));
    return tmp.innerText.trim().replace(/\n{3,}/g, '\n\n');
  }

  function exportProjectCSV(posts, baseName) {
    exportToCSV(posts, ['작성자','날짜','제목','내용_html','댓글'], `${baseName}_viewer.csv`);
    const textPosts = posts.map(r => [
      r[0], r[1], r[2],
      htmlToText(r[3]),
      r[4].split(' | ').map(c => {
        const m = c.match(/^\[(.+?)\]\s*([\s\S]*)$/);
        return m ? `[${m[1]}] ${htmlToText(m[2])}` : htmlToText(c);
      }).join(' | ')
    ]);
    exportToCSV(textPosts, ['작성자','날짜','제목','내용','댓글'], `${baseName}_plain.csv`);
  }

  // ════════════════════════════════
  // 채팅 백업
  // ════════════════════════════════
  function findChatContainer() {
    const el = document.querySelector('ul.chat-container');
    if (el) return el;
    return Array.from(document.querySelectorAll('ul,div'))
      .filter(d => d.scrollHeight > d.clientHeight + 100)
      .sort((a, b) => b.scrollHeight - a.scrollHeight)[0] || null;
  }

  function collectChatMessages(container, collectedIds, messages) {
    let currentDate = '';
    Array.from(container.children).forEach(child => {
      if (child.classList && child.classList.contains('chat-date')) {
        const span = child.querySelector('span');
        if (span) currentDate = span.innerText.trim();
        return;
      }
      if (!child.classList || !child.classList.contains('message-item')) return;
      const id = child.id;
      if (!id || collectedIds.has(id)) return;

      const isRight = child.classList.contains('right-section');
      const sender = isRight
        ? '나'
        : (child.getAttribute('rgsr_nm') || child.querySelector('.js-user-title strong, .user-title strong')?.innerText?.trim() || '');

      const timeEl = child.querySelector('.user-time');
      const time = timeEl ? timeEl.innerText.trim() : '';

      const contentsEl = child.querySelector('.js-contents.chat-txt-contents, .chat-txt-contents');
      let body = '';
      if (contentsEl) {
        const clone = contentsEl.cloneNode(true);
        clone.querySelectorAll('i, button').forEach(e => e.remove());
        body = clone.innerText.trim().replace(/\r?\n/g, '↵');
      }
      if (!body) {
        const imgList = child.querySelector('.js-image-list');
        if (imgList && imgList.children.length > 0) body = `(이미지/첨부 ${imgList.children.length}개)`;
      }
      if (!body) return;

      collectedIds.add(id);
      messages.push([sender, currentDate, time, body]);
    });
  }

  async function startChatBackup() {
    const speed = parseInt(document.getElementById('fb-speed').value);
    stopFlag = false;
    document.getElementById('fb-start').style.display = 'none';
    document.getElementById('fb-stop').style.display = 'block';
    startTimer();
    setStatus('⏳ 채팅 영역 탐색 중...', 0);

    const container = findChatContainer();
    if (!container) { setStatus('❌ 채팅 컨테이너를 찾지 못했습니다.'); resetUI(); return; }

    const roomNameEl = document.querySelector('[class*="room-title"],[class*="chat-title"],.room-name');
    const roomName = (roomNameEl ? roomNameEl.innerText.trim() : 'chat').slice(0,20).replace(/[\\/:*?"<>|]/g,'_');

    const collectedIds = new Set();
    const messages = [];
    const liEl = container.querySelector('li.message-item');
    const scrollStep = (liEl ? liEl.offsetHeight : 80) * 2;

    collectChatMessages(container, collectedIds, messages);
    let noNewCount = 0;

    while (!stopFlag) {
      const prevCount = messages.length;
      const prevScrollHeight = container.scrollHeight;
      const prevScrollTop = container.scrollTop;

      collectChatMessages(container, collectedIds, messages);

      // 위로 스크롤 — scrollTop을 직접 빼면 새 메시지 로드 후 위치가 밀려서 제자리가 됨
      // 때문에 scrollHeight 증가분만큼 추가로 더 올려줘야 실제로 위로 이동됨
      container.scrollTop = Math.max(0, prevScrollTop - scrollStep);
      await sleep(speed);

      const added = container.scrollHeight - prevScrollHeight;
      if (added > 0) {
        // 새 메시지가 위에 추가되면서 scrollHeight가 늘었으면 그만큼 보정
        container.scrollTop = Math.max(0, container.scrollTop - added);
        await sleep(400);
      }

      collectChatMessages(container, collectedIds, messages);

      const total = container.scrollHeight - container.clientHeight;
      setStatus(`⏳ 수집 중... ${messages.length}개`, Math.min(99, 100 - Math.round((container.scrollTop / total) * 100)));

      if (container.scrollTop <= 0) { await sleep(speed); collectChatMessages(container, collectedIds, messages); break; }
      // noNewCount 10으로 완화 (lazy load 대기 시간 확보)
      if (messages.length === prevCount) { if (++noNewCount >= 10) break; } else { noNewCount = 0; }
    }

    if (messages.length === 0) { setStatus('❌ 메시지를 찾지 못했습니다.'); resetUI(); return; }

    exportToCSV(messages, ['발신자','날짜','시간','내용'], `flow_chat_${roomName}_${nowStr()}.csv`);
    setStatus(`✅ 완료! ${messages.length}개 저장됨`, 100);
    resetUI();
  }

  // ════════════════════════════════
  // 프로젝트 백업
  // ════════════════════════════════
  function findProjectContainer() {
    return document.querySelector('.project-detail-inner') || null;
  }

  function collectProjectPosts(container, collectedIds, posts) {
    const cards = container.querySelectorAll('li.pj-post__item');
    cards.forEach(card => {
      const id = card.id || card.getAttribute('data-srno') || card.querySelector('[data-srno]')?.getAttribute('data-srno');
      if (!id) return;

      const isPinned = card.classList.contains('pj-post__item--pinned');
      const title = isPinned
        ? (card.querySelector('h5.post__tit, .js-post-title')?.innerText.trim() || '')
        : (card.querySelector('h4.post-title, .post-title')?.innerText.trim() || '');
      if (!title) return;

      const key = id;
      if (collectedIds.has(key)) return;

      const author = isPinned
        ? (card.querySelector('.post__author')?.innerText.trim() || '')
        : (card.querySelector('strong.author, .author')?.innerText.trim() || '');
      if (!author) return;

      const date = isPinned
        ? (card.querySelector('.post__date')?.innerText.trim() || '')
        : (card.querySelector('.date')?.innerText.trim() || '');

      const bodyEl = card.querySelector('.post-editor-wrap');
      const body = bodyEl ? bodyEl.innerHTML.trim() : '';

      const comments = [];
      card.querySelectorAll('li.remark-item').forEach(r => {
        const cAuthor = r.querySelector('.user-name')?.innerText.trim() || '';
        const cDate   = r.querySelector('.record-date')?.innerText.trim() || '';
        const cTextEl = r.querySelector('.comment-text');
        const cText   = cTextEl ? cTextEl.innerHTML.trim() : '';
        if (cText) comments.push(`[${cAuthor} ${cDate}] ${cText}`);
      });

      collectedIds.add(key);
      posts.push([author, date, title, body, comments.join(' | ')]);
    });
  }

  async function startProjectBackup() {
    const speed = parseInt(document.getElementById('fb-speed').value);
    stopFlag = false;
    document.getElementById('fb-start').style.display = 'none';
    document.getElementById('fb-stop').style.display = 'block';
    startTimer();
    setStatus('⏳ 프로젝트 탐색 중...', 0);

    const container = findProjectContainer();
    if (!container) { setStatus('❌ 프로젝트 컨테이너를 찾지 못했습니다.'); resetUI(); return; }

    const projectNameEl = document.querySelector('h3.project-title.ellipsis, h3.project-title, .js-post-popup-project-title-area');
    const projectName = (projectNameEl ? projectNameEl.innerText.trim() : 'project').slice(0,20).replace(/[\\/:*?"<>|]/g,'_');

    const collectedIds = new Set();
    const posts = [];

    collectProjectPosts(container, collectedIds, posts);
    let noNewCount = 0;

    while (!stopFlag) {
      const prevCount = posts.length;
      const prevScrollHeight = container.scrollHeight;

      container.scrollTop += container.clientHeight * 0.7;
      await sleep(speed);
      if (container.scrollHeight > prevScrollHeight) await sleep(500);

      collectProjectPosts(container, collectedIds, posts);

      const total = container.scrollHeight - container.clientHeight;
      const progress = total > 0 ? Math.min(99, Math.round((container.scrollTop / total) * 100)) : 99;
      setStatus(`⏳ 수집 중... ${posts.length}건`, progress);

      if (container.scrollTop + container.clientHeight >= container.scrollHeight - 10) {
        await sleep(speed);
        collectProjectPosts(container, collectedIds, posts);
        break;
      }
      if (posts.length === prevCount) { if (++noNewCount >= 10) break; } else { noNewCount = 0; }
    }

    if (posts.length === 0) { setStatus('❌ 게시글을 찾지 못했습니다.'); resetUI(); return; }

    const baseName = `flow_project_${projectName}_${nowStr()}`;
    exportProjectCSV(posts, baseName);
    setStatus(`✅ 완료! ${posts.length}건 저장됨\n뷰어용·일반용 2개 다운로드`, 100);
    resetUI();
  }

  // ── 버튼 이벤트 ──
  document.getElementById('fb-start').addEventListener('click', () => {
    if (currentMode === 'chat') startChatBackup();
    else if (currentMode === 'project') startProjectBackup();
  });
  document.getElementById('fb-stop').addEventListener('click', () => { stopFlag = true; });

  // ── URL 변화 감지 및 패널 표시/갱신 ──
  function updatePanel() {
    const mode = detectMode();
    if (mode === currentMode) return;
    currentMode = mode;

    if (!mode) {
      panel.style.display = 'none';
      return;
    }

    panel.style.display = 'block';
    if (mode === 'chat') {
      document.getElementById('fb-title').textContent = '💬 채팅 백업';
      document.getElementById('fb-mode-badge').textContent = '📍 채팅 모드';
      setStatus('채팅방을 열고 시작하세요.');
    } else {
      document.getElementById('fb-title').textContent = '📋 프로젝트 백업';
      document.getElementById('fb-mode-badge').textContent = '📍 프로젝트 모드';
      setStatus('프로젝트 페이지에서 시작하세요.');
    }
    resetUI();
    document.getElementById('fb-prog-wrap').style.display = 'none';
  }

  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(updatePanel, 800);
    }
  }).observe(document.body, { childList: true, subtree: true });

  updatePanel();
})();
